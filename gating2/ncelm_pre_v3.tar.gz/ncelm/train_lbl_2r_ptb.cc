// Copyright (c) 2006-2013 Andriy Mnih
#include <stdio.h>
#include "net_lbl_2reps_scalable.h"
#include "word_io.h"

int main()
{
    printf("Loading data... ");
    WordStream traindata("treebank/ptb_train_stream.dat");
    WordStream validdata("treebank/ptb_valid_stream.dat");
    printf("Done.\n");

    const int contextSize = 2;
    const int nWords      = 10001;
    const int nContextRepDims = 100;
    const int nTargetRepDims  = 100;

    Net_LBL_2Reps_Scalable_Params params;
    params.initWeightSizeC  = 1e-1;
    params.initWeightSizeCR = 1e-1;
    params.initWeightSizeTR = 1e-1;

    Net_LBL_2Reps_Scalable net(contextSize, nWords, nContextRepDims, nTargetRepDims, params);

    Net_LBL_2Reps_Scalable_TrainParams trainparams;

    trainparams.nEpochs = 100;

    trainparams.learnRateC   = 1e-4;
    trainparams.learnRateCR  = 3e-3;
    trainparams.learnRateTR  = 3e-2;
    trainparams.learnRateWB  = 1e-3;
    trainparams.weightCostC  = 0;
    trainparams.weightCostCR = 0;
    trainparams.weightCostTR = 0;
    trainparams.weightCostWB = 0;

    trainparams.printFreq = 100;
    trainparams.validFreq = 4500;
    trainparams.saveFreq = int(1e7);
    trainparams.pplStride = validdata.length() / 10000;

    trainparams.batchSize = 100;
    trainparams.sampleCases = 1;
    trainparams.objective     = OBJ_NC;
    trainparams.uniformMixProb = 0;
    trainparams.nNoiseSamples = 25;

    trainparams.lrDownscale = 0.5;

    trainparams.filename = "train_lbl_2r_ptb.save";

    net.initWordBiases(traindata);
    net.train(traindata, validdata, trainparams);
    return 0;
}
