// Copyright (c) 2006-2013 Andriy Mnih
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "word_io.h"

const size_t chunkSize = 1024*1024*1024 / 4;

WordStream::WordStream(const char *filename)
{
    struct stat  fileStats;

    myStream = 0;

    if (!stat(filename, &fileStats))
    {
        myLength = fileStats.st_size/sizeof(int);
        myStream = new int[myLength];

        assert(size_t(myLength*sizeof(int)) == size_t(fileStats.st_size));

        FILE *fp = fopen(filename, "rb");
        if (fp == 0)
        {
            fprintf(stderr, "Error opening file %s.\n", filename);
            exit(-1);
        }

        size_t totalRead = 0;
        size_t wordsRead = 0;

        int nChunks = myLength / chunkSize;
        if (nChunks*chunkSize < myLength)
            nChunks += 1;
//        printf("nChunks = %d\n", nChunks);

        int *buffer = myStream;
        for (int c = 0; c < nChunks; c++)
        {
            const int readSize = (c == nChunks-1) ? myLength % chunkSize : chunkSize;
            wordsRead = fread(buffer, sizeof(int), readSize, fp);
            buffer += wordsRead;

            totalRead += wordsRead;
        }

//        printf("totalRead = %lu\n", totalRead);
        if (totalRead < myLength)
        {
            fprintf(stderr, "Error reading file %s.\n", filename);
            exit(-2);
        }

        fclose(fp);
    }
    else
    {
        myLength = 0;
        myStream = 0;
        fprintf(stderr, "Error: Cannot stat file %s.\n", filename);
        exit(-3);
    }
}

WordStream::WordStream(const int *data, int len)
{
    myLength = len;

    myStream = new int[myLength];

    for (size_t i = 0; i < myLength; i++)
        myStream[i] = data[i];
}

WordStream::~WordStream()
{
    if (myLength)
        delete [] myStream;
}

void
WordStream::subStream(size_t firstIdx, size_t lastIdx)
{
    const int *oldStream = myStream;

    assert(lastIdx < length());

    myLength = lastIdx - firstIdx + 1;
    myStream = new int[length()];

    for (size_t i = 0; i < length(); i++)
        myStream[i] = oldStream[firstIdx + i];

    delete [] oldStream;
}

int
WordStream::maxVal() const
{
    int maxVal = 0;

    for (size_t i = 0; i < length(); i++)
    {
        if (maxVal < myStream[i])
            maxVal = myStream[i];
    }

    return maxVal;
}

void
WordStream::reverseStream()
{
    int word;
    int len = length();

    for (int i = 0; i < len / 2; i++)
    {
        word = myStream[i];
        myStream[i] = myStream[len-i-1];
        myStream[len-i-1] = word;
    }
}

void
WordStream::filterOutWord(int word)
{
    int idx = 0;
    for (size_t i = 0; i < length(); i++)
    {
        if (myStream[i] != word)
            myStream[idx++] = myStream[i];
    }

    printf("Filtered out %d occurrences of word %d\n", int(myLength)-idx, word);
    myLength = size_t(idx);
}
