// Copyright (c) 2006-2013 Andriy Mnih
#ifndef __NET_LBL_VEC_H__
#define __NET_LBL_VEC_H__

#include <vector>
#include "Matrix.h"

using namespace std;

class Net_LBL_2Reps_Scalable_TrainParams;
class WordStream;

struct Net_LBL_2Reps_Scalable_Params {
    float         initWeightSizeTR;
    float         initWeightSizeCR;
    float         initWeightSizeC;

                  Net_LBL_2Reps_Scalable_Params();
};

class Net_LBL_2Reps_Scalable {
private:
    int          contextSize_;
    int          nWords_;
    int          nContextDims_;
    int          nTargetDims_;

    Net_LBL_2Reps_Scalable_Params params_;

    Matrix       contextWeights_;
    Vector      *contextReps_;
    Matrix       targetRepMat_;
    Vector       wordBiases_;

    mutable Matrix predRepMat_;
    mutable Matrix predProbsMat_;
    mutable Matrix contextRepMat_;

    Matrix       contextWeightGrad_;

    int          load(const char *filename);

    void         computeContextIds(vector<int> &contextIds, const WordStream &traindata, int nCases) const;

    void         computePredReps(Matrix &predRepMat, Matrix &contextRepMat, const vector<const int *> &sequences) const;
    void         computePredProbs(Matrix &predProbMat, const Matrix &predRepMat) const;

    void         applyContextRepDelta(const Matrix &contextRepGrad, const vector<const int *> &sequences);

    void         sampleNegWords(vector<int>                   &negWords,
                                vector<float>                 &negNoiseProbs,
                                const WordStream              &sampleData,
                                const vector<float>           &unigram,
                                const Net_LBL_2Reps_Scalable_TrainParams &params) const;

    float        updateParamsML(const vector<const int *> &sequences,
                                float                      globalLrScale,
                                const Net_LBL_2Reps_Scalable_TrainParams &params);
    float        updateParamsNC(const vector<const int *> &sequences,
                                const vector<int>         &negWords,
                                const vector<float>       &posNoiseProbs,
                                const vector<float>       &negNoiseProbs,
                                float                     &dataLogisticLogProbSum,
                                float                     &noiseLogisticLogProbSum,
                                float                      globalLrScale,
                                const Net_LBL_2Reps_Scalable_TrainParams &params);

public:
                 Net_LBL_2Reps_Scalable(int contextSize, int nWords, int nContextDims, int nTargetDims,
                               const Net_LBL_2Reps_Scalable_Params &params);
                 Net_LBL_2Reps_Scalable(const char *filename);
                ~Net_LBL_2Reps_Scalable(); 

    int          contextSize() const { return contextSize_; }
    int          nWords()      const { return nWords_; }
    int          nContextDims()    const { return nContextDims_; }
    int          nTargetDims()     const { return nTargetDims_; }

//    float        logProbSum(const int *sequence) const;
    float        perplexity(const WordStream &stream, int stride = 1) const;

    void         printPerBinPerplexity(const WordStream &data,
                                       const vector<int> &condWordBins,
                                       const vector<int> &targWordBins,
                                       const vector<float> &logBaseRates,
                                       const Net_LBL_2Reps_Scalable_TrainParams &params) const;

    int          save(const char *filename) const;

    void         initWordBiases(const WordStream &stream);
    void         initWordBiasesUniform();
    void         printStats(int epoch, int batch, float meanLogP, float logZNorm = 0,
                            float meanDataLLP = 0, float meanNoiseLLP = 0) const;

    void         train(const WordStream &traindata,
                       const WordStream &validdata,
                       const Net_LBL_2Reps_Scalable_TrainParams &params);
};


enum OptObjective {
    OBJ_LIKELIHOOD = 0,
    OBJ_NC
};

struct Net_LBL_2Reps_Scalable_TrainParams {
    float         learnRateC;
    float         learnRateCR;
    float         learnRateTR;
    float         learnRateWB;

    float         weightCostC;
    float         weightCostCR;
    float         weightCostTR;
    float         weightCostWB;

    int           printFreq;
    int           validFreq;
    int           saveFreq;

    int           nEpochs;

    float         uniformMixProb;
    int           nNoiseSamples;
    int           sampleCases;

    float         lrDownscale;
    float         initLrScale;

    int           pplStride;

    int           batchSize;

    OptObjective  objective;

    const char   *filename;

                  Net_LBL_2Reps_Scalable_TrainParams();
};

#endif
