// Copyright (c) 2006-2013 Andriy Mnih
#ifndef __WORD_IO_H__
#define __WORD_IO_H__

class WordStream {
private:
    int         *myStream;
    size_t       myLength;
public:
                 WordStream(const char *filename);
                 WordStream(const int *data, int len);
                ~WordStream();

    size_t       length() const { return myLength; }
    int          maxVal() const;
    const int   *stream(int i = 0) const { return &myStream[i]; }

    void         subStream(size_t firstIdx, size_t lastIdx);
    void         reverseStream();

    void         reduceVocab(int nWords);
    void         filterOutWord(int word);
};

#endif
