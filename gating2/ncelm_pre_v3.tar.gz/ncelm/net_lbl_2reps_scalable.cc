// Copyright (c) 2006-2013 Andriy Mnih
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "net_lbl_2reps_scalable.h"
#include <algorithm>
#include <utility>
#include <boost/functional/hash.hpp>
#include <boost/tr1/unordered_map.hpp>
#include "util.h"
#include "word_io.h"


Net_LBL_2Reps_Scalable::Net_LBL_2Reps_Scalable(int contextSize, int nWords,
                             int nContextDims, int nTargetDims,
                             const Net_LBL_2Reps_Scalable_Params &params):
                             params_(params), wordBiases_(nWords)
{
    contextSize_  = contextSize;
    nWords_       = nWords;
    nContextDims_ = nContextDims;
    nTargetDims_  = nTargetDims;

    contextWeights_.resize(contextSize*nContextDims, nTargetDims);
    contextWeights_.initFromGaussian(params_.initWeightSizeC);

    contextReps_ = new Vector[nWords];
    for (int i = 0; i < nWords; i++)
    {
        contextReps_[i].resize(nContextDims);
        contextReps_[i].initFromGaussian(params_.initWeightSizeCR);
    }

    targetRepMat_.resize(nTargetDims, nWords);
    targetRepMat_.initFromGaussian(params_.initWeightSizeTR);

    contextWeightGrad_.resize(contextSize*nContextDims, nTargetDims);
}

Net_LBL_2Reps_Scalable::Net_LBL_2Reps_Scalable(const char *filename)
{
    load(filename);

    contextWeightGrad_.resize(contextSize()*nContextDims(), nTargetDims());
}

Net_LBL_2Reps_Scalable::~Net_LBL_2Reps_Scalable()
{
    if (contextReps_)
        delete [] contextReps_;
}

inline void
Net_LBL_2Reps_Scalable::computePredReps(Matrix &predRepMat, Matrix &contextRepMat, const vector<const int *> &sequences) const
{
    assert(contextRepMat.cols() >= int(sequences.size()));
    assert(contextRepMat.rows() == nContextDims()*contextSize());

    for (size_t s = 0; s < sequences.size(); s++)
    {
        float *contextRep = contextRepMat.col(s);
        if (sequences[s])
        {
            for (int c = 0; c < contextSize(); c++)
            {
                const float *wordRep = contextReps_[sequences[s][c]].data();
                for (int j = 0; j < nContextDims(); j++)
                    *contextRep++ = *wordRep++;
            }
        }
        else
        {
            // Zero out the context rep for an empty (padded) context.
            for (int j = 0; j < contextSize()*nContextDims(); j++)
                *contextRep++ = 0;

        }
    }

    predRepMat.scaleAddAtransB(contextWeights_, contextRepMat, 0);
}

inline void
Net_LBL_2Reps_Scalable::computePredProbs(Matrix &predProbsMat, const Matrix &predRepMat) const
{
    predProbsMat.fillColumns(wordBiases_);
    predProbsMat.scaleAddAtransB(targetRepMat_, predRepMat, 1);
    predProbsMat.softMaxColumns();
}

float
Net_LBL_2Reps_Scalable::perplexity(const WordStream &data, int stride) const
{
    assert(data.length() > 0);

    const int batchSize = 1000;
    const int dataLen = data.length();

    // Instead of adjusting batchSize to find nCases, use a fixed batchSize
    // and compute the logPSumSum when either the batch is full or when all
    // out of datacases.

    Matrix contextRepMat(contextSize()*nContextDims(), batchSize);
    Matrix predRepMat(nTargetDims(), batchSize);
    Matrix predProbsMat(nWords(), batchSize);

    double logPSumSum = 0;
    int caseCount = 0;
    int bIdx = 0;
    vector<const int *> sequences(batchSize);
    for (int caseIdx = 0; caseIdx < dataLen; caseIdx += stride)
    {
        if (caseIdx < contextSize())
            continue;

        const int *sequence = data.stream(caseIdx-contextSize());

        assert(bIdx < batchSize);
        sequences[bIdx] = sequence;
        bIdx += 1;

        if (bIdx == batchSize || caseIdx+stride >= dataLen)
        {
            // Pad the the leftover cases in the batch.
            for (int s = bIdx; s < batchSize; s++)
                sequences[s] = 0;

            computePredReps(predRepMat, contextRepMat, sequences);
            computePredProbs(predProbsMat, predRepMat);

            for (int s = 0; s < bIdx; s++)
                logPSumSum += logf(predProbsMat.col(s)[sequences[s][contextSize()]]);
            caseCount += bIdx;
            bIdx = 0;
        }
    }
    
    return expf(-logPSumSum / caseCount);
}

void
Net_LBL_2Reps_Scalable::applyContextRepDelta(const Matrix &contextRepGrad, const vector<const int *> &sequences)
{
    for (int i = 0; i < contextRepGrad.cols(); i++)
    {
        const float *grad = contextRepGrad.col(i);
        const int *sequence = sequences[i];
        for (int c = 0; c < contextSize(); c++)
        {
            float *rep = contextReps_[sequence[c]].data();
            for (int j = 0; j < nContextDims(); j++)
                rep[j] += grad[j];

            grad += nContextDims();
        }
    }
}

float
Net_LBL_2Reps_Scalable::updateParamsML(const vector<const int *> &sequences,
                                       float                      globalLrScale,
                                       const Net_LBL_2Reps_Scalable_TrainParams &params)
{
    const int batchSize = sequences.size();

    computePredReps(predRepMat_, contextRepMat_, sequences);    // Compute the predicted rep
    computePredProbs(predProbsMat_, predRepMat_);               // Compute the distribution for the next word

    // Compute the difference between the empirical and the predicted probs.
    Matrix probDiffMat(nWords(), batchSize);
    for (int i = 0; i < batchSize; i++)
    {
        const float *source = predProbsMat_.col(i);
        float       *target = probDiffMat.col(i);
        for (int j = 0; j < nWords(); j++)
            target[j] = -source[j];

        const int targetWord = sequences[i][contextSize()];
        target[targetWord] += 1.f;
    }

    // Compute the difference between the rep for the target word and the expected rep.
    Matrix repDiffMat(nTargetDims(), batchSize);
    repDiffMat.scaleAddAB(targetRepMat_, probDiffMat, 0);

    const float learnRateC  = globalLrScale*params.learnRateC;
    const float learnRateCR = globalLrScale*params.learnRateCR;
    const float learnRateTR = globalLrScale*params.learnRateTR;
    const float learnRateWB = globalLrScale*params.learnRateWB;

    // contextWeightGrad_.zero(); // Redundant now
    contextWeightGrad_.scaleAddABtrans(contextRepMat_, repDiffMat, 0, learnRateC);

    Matrix contextRepGrad(contextSize()*nContextDims(), batchSize);
    contextRepGrad.scaleAddAB(contextWeights_, repDiffMat, 0, learnRateCR);
    applyContextRepDelta(contextRepGrad, sequences);

    targetRepMat_.scaleAddABtrans(predRepMat_, probDiffMat, 1, learnRateTR);

    probDiffMat.addScaledColumnSum(&wordBiases_, learnRateWB);

    contextWeights_.add(&contextWeightGrad_);

    double logPSumSum = 0;
    for (int i = 0; i < batchSize; i++)
    {
        const int targetWord = sequences[i][contextSize()];
        logPSumSum += logf(predProbsMat_.col(i)[targetWord]);
    }

    // Apply the weight cost update
    contextWeights_.decayL2(learnRateC*params.weightCostC);
    wordBiases_.decayL2(learnRateWB*params.weightCostWB);
    targetRepMat_.decayL2(learnRateTR*params.weightCostTR);
    for (int i = 0; i < batchSize; i++)
    {
        for (int c = 0; c < contextSize(); c++)
            contextReps_[sequences[i][c]].decayL2(learnRateCR*params.weightCostCR);
    }

    return logPSumSum;
}

inline float
computePosWeight(float modelP, float noiseP, OptObjective obj)
{
    switch (obj)
    {
        case OBJ_NC:        return noiseP / (modelP + noiseP);
        default:            assert(!"Unknown objective!");
    }
}

inline float
computeNegWeight(float modelP, float noiseP, OptObjective obj)
{
    switch (obj)
    {
        case OBJ_NC:        return modelP / (modelP + noiseP);
        default:            assert(!"Unknown objective!");
    }
}

float
Net_LBL_2Reps_Scalable::updateParamsNC(const vector<const int *> &sequences,
                              const vector<int>         &negWords,
                              const vector<float>       &posNoiseProbs,
                              const vector<float>       &negNoiseProbs,
                              float                     &dataLogisticLogProbSum,
                              float                     &noiseLogisticLogProbSum,
                              float                      globalLrScale,
                              const Net_LBL_2Reps_Scalable_TrainParams &params)
{
    const int batchSize = sequences.size();
    const int nSamples  = params.nNoiseSamples;

    computePredReps(predRepMat_, contextRepMat_, sequences);    // Compute the predicted rep

    vector<float> posWeights(batchSize);
    vector<float> negWeights(batchSize*nSamples);

    double logPSum = 0;
    Vector predRep(nTargetDims(), false, 0);
    Vector posRep (nTargetDims(), false, 0);
    Vector negRep (nTargetDims(), false, 0);

    for (int i = 0; i < batchSize; i++)
    {
        const int posWord = sequences[i][contextSize()];

        predRep.myData = predRepMat_.col(i);
        posRep.myData  = targetRepMat_.col(posWord);

        const float posInput = wordBiases_[posWord] + dot(predRep, posRep);
        const float modelPosP = exp(posInput);
        const float posWeight = computePosWeight(modelPosP, nSamples*posNoiseProbs[i], params.objective);

        posWeights[i] = posWeight;
        dataLogisticLogProbSum += log(posWeight+FLT_MIN);

        const int startIdx = i*nSamples;
        for (int sampleIdx = startIdx; sampleIdx < startIdx + nSamples; sampleIdx++)
        {
            const int negWord = negWords[sampleIdx];
            negRep.myData  = targetRepMat_.col(negWord);

            const float negInput = wordBiases_[negWord] + dot(predRep, negRep);
            const float modelNegP = exp(negInput);
            const float negWeight = computeNegWeight(modelNegP, nSamples*negNoiseProbs[sampleIdx], params.objective);
            negWeights[sampleIdx] = negWeight;

            noiseLogisticLogProbSum += log(negWeight+FLT_MIN) / nSamples;
        }

        logPSum += logf(modelPosP+FLT_MIN);
    }

    Matrix weightedRepDiffMat(nTargetDims(), batchSize);
    Vector weightedRepDiff(nTargetDims(), false, 0);
    for (int i = 0; i < batchSize; i++)
    {
        const int   posWord   = sequences[i][contextSize()];
        const float posWeight = posWeights[i];

        posRep.myData = targetRepMat_.col(posWord);
        weightedRepDiff.myData = weightedRepDiffMat.col(i);
        weightedRepDiff.addScaled(&posRep, +posWeight);

        float meanNegWeight = 0;
        const int startIdx = i*nSamples;
        for (int sampleIdx = startIdx; sampleIdx < startIdx + nSamples; sampleIdx++)
        {
            const int   negWord   = negWords  [sampleIdx];
            const float negWeight = negWeights[sampleIdx];

            negRep.myData = targetRepMat_.col(negWord);
            weightedRepDiff.addScaled(&negRep, -negWeight);

            meanNegWeight += negWeight;
        }
    }

    const float learnRateC  = globalLrScale*params.learnRateC;
    const float learnRateCR = globalLrScale*params.learnRateCR;
    const float learnRateTR = globalLrScale*params.learnRateTR;
    const float learnRateWB = globalLrScale*params.learnRateWB;

    contextWeightGrad_.scaleAddABtrans(contextRepMat_, weightedRepDiffMat, 0, learnRateC);

    Matrix contextRepGrad(contextSize()*nContextDims(), batchSize);
    contextRepGrad.scaleAddAB(contextWeights_, weightedRepDiffMat, 0, learnRateCR);
    applyContextRepDelta(contextRepGrad, sequences);

    for (int i = 0; i < batchSize; i++)
    {
        const int   posWord   = sequences[i][contextSize()];
        const float posWeight = posWeights[i];

        predRep.myData = predRepMat_.col(i);
        posRep.myData = targetRepMat_.col(posWord);
        posRep.addScaled(&predRep, +learnRateTR*posWeight);
        wordBiases_[posWord] += learnRateWB*posWeight;

        const int startIdx = i*nSamples;
        for (int sampleIdx = startIdx; sampleIdx < startIdx + nSamples; sampleIdx++)
        {
            const int   negWord   = negWords  [sampleIdx];
            const float negWeight = negWeights[sampleIdx];

            negRep.myData = targetRepMat_.col(negWord);
            negRep.addScaled(&predRep, -learnRateTR*negWeight);
            wordBiases_[negWord] -= learnRateWB*negWeight;
        }
    }

    contextWeights_.add(&contextWeightGrad_);

    // Apply the weight cost update
    contextWeights_.decayL2(learnRateC*params.weightCostC);
    for (int i = 0; i < batchSize; i++)
    {
        const int posWord = sequences[i][contextSize()];

        wordBiases_[posWord] *= (1.-learnRateWB*params.weightCostWB);

        posRep.myData = targetRepMat_.col(posWord);
        posRep.decayL2(learnRateTR*params.weightCostTR);

        const int startIdx = i*nSamples;
        for (int sampleIdx = startIdx; sampleIdx < startIdx + nSamples; sampleIdx++)
        {
            const int negWord = negWords[sampleIdx];

            wordBiases_[negWord] *= (1.-learnRateWB*params.weightCostWB);

            negRep.myData = targetRepMat_.col(negWord);
            negRep.decayL2(learnRateTR*params.weightCostTR);
        }

        for (int c = 0; c < contextSize(); c++)
            contextReps_[sequences[i][c]].decayL2(learnRateCR*params.weightCostCR);
    }

    return logPSum;
}

inline int
sampleNegWord(float                         &negNoiseProb,
              const WordStream              &sampleData,
              const vector<float>           &unigram,
              int                            nWords,
              const Net_LBL_2Reps_Scalable_TrainParams &params)
{
    const float p1 = params.uniformMixProb;
    const float p2 = 1. - params.uniformMixProb;
    const float unif = 1. / nWords;

    int negWord;
    if (::Rand() < params.uniformMixProb)
         negWord = rand() % nWords;
    else negWord = *sampleData.stream(rand() % sampleData.length());

    negNoiseProb = p1*unif + p2*unigram[negWord];

    return negWord;
}

inline void
Net_LBL_2Reps_Scalable::sampleNegWords(vector<int>                   &negWords,
                              vector<float>                 &negNoiseProbs,
                              const WordStream              &sampleData,
                              const vector<float>           &unigram,
                              const Net_LBL_2Reps_Scalable_TrainParams &params) const
{
    const int batchSize = negWords.size();

    const float p1 = params.uniformMixProb;
    const float p2 = 1. - params.uniformMixProb;
    const float unif = 1. / nWords();
    for (int i = 0; i < batchSize; i++)
    {
        if (::Rand() < params.uniformMixProb)
             negWords[i] = rand() % nWords();
        else negWords[i] = *sampleData.stream(rand() % sampleData.length());

        negNoiseProbs[i] = p1*unif + p2*unigram[negWords[i]];
    }
}

void
Net_LBL_2Reps_Scalable::train(const WordStream &traindata, const WordStream &validdata, const Net_LBL_2Reps_Scalable_TrainParams &params)
{
    const int nCases   = traindata.length() - contextSize() - 1;
    const int nSamples = params.nNoiseSamples;

    assert(params.sampleCases);

    vector<float> unigram(nWords());
    // Fit a unigram model to the data.
    for (int i = 0; i < nCases; i++)
    {
        const int w = *traindata.stream(i);
        unigram[w] += 1;
    }

    for (int w = 0; w < nWords(); w++)
        unigram[w] /= nCases;

    vector<int> negWords(params.batchSize*nSamples);
    vector<float> posNoiseProbs(params.batchSize);
    vector<float> negNoiseProbs(params.batchSize*nSamples);

//    printf("PPL = %8.4f\n", perplexity(validdata, params.pplStride)); fflush(stdout);

    vector<const int *> batchSequences(params.batchSize);

    predRepMat_.resize(nTargetDims(), params.batchSize);
    predProbsMat_.resize(nWords(), params.batchSize);
    contextRepMat_.resize(contextSize()*nContextDims(), params.batchSize);

    // TODO Handle incomplete batches!!! 

    const int nBatches = int(::ceil(double(nCases) / params.batchSize));
    printf("nWords = %8d   nBatches = %8d  batchSize = %5d\n", nWords(), nBatches, params.batchSize);

    float bestPPL = FLT_MAX;
    float prevPPL = FLT_MAX;
    float lrScale = params.initLrScale;
    for (int epoch = 0; epoch < params.nEpochs; epoch++)
    {
        float dataLLP  = 0;
        float noiseLLP = 0;
        double logPSum = 0;
        int    sumCount = 0;
        for (int b = 0; b < nBatches; b++)
        {
            const int batchSize = min(params.batchSize, nCases - b*params.batchSize);
            if (batchSize != params.batchSize)
                break;

            const float p1 = params.uniformMixProb;
            const float p2 = 1. - params.uniformMixProb;
            const float unif = 1. / nWords();
            for (int i = 0; i < batchSize; i++)
            {
                const int caseIdx = rand() % nCases;
                batchSequences[i] = traindata.stream(caseIdx);

                if (params.objective != OBJ_LIKELIHOOD)
                {
                    posNoiseProbs[i] = p1*unif + p2*unigram[batchSequences[i][contextSize()]];
                }
            }

            if (params.objective == OBJ_LIKELIHOOD)
            {
                logPSum += updateParamsML(batchSequences, lrScale, params);
            }
            else
            {
                sampleNegWords(negWords, negNoiseProbs, traindata, unigram, params);
                logPSum += updateParamsNC(batchSequences, negWords, posNoiseProbs, negNoiseProbs, dataLLP, noiseLLP, lrScale, params);
            }

            sumCount += batchSize;

            if ((b+1) % params.printFreq == 0)
            {
                printStats(epoch, b, logPSum/sumCount, 0, dataLLP/sumCount, noiseLLP/sumCount);
                logPSum = 0;
                dataLLP  = 0;
                noiseLLP = 0;
                sumCount = 0;
            }

            if ((b+1) % params.saveFreq == 0 && params.filename)
            {
                save(params.filename);
            }
        }

        const float currPPL = perplexity(validdata, params.pplStride);
        printf("epochPPL = %10.3f\n", currPPL);
        if (currPPL < bestPPL && params.filename)
        {
            char bestname[256] = {0};
            sprintf(bestname, "%s_best", params.filename);
            save(bestname);
            bestPPL = currPPL;
            printf("best model saved after epoch %d\n", epoch+1);
        }

        printf("lrScale = %e\n", lrScale);
        if (prevPPL < currPPL) 
            lrScale *= params.lrDownscale;
        prevPPL = currPPL;
        fflush(stdout);
    }
}

void
Net_LBL_2Reps_Scalable::printStats(int epoch, int batch, float meanLogP, float logZNorm, float meanDataLLP, float meanNoiseLLP) const
{
    double crNorm2 = 0;
    for (int i = 0; i < nWords(); i++)
        crNorm2 += contextReps_[i].norm2();

    printf("%3d / %5d  ", epoch, batch);
    printf("|c|= %8.4f ",  contextWeights_.norm());
    printf("|cr|= %8.4f ",  sqrt(crNorm2));
    printf("|tr|= %8.4f ",  targetRepMat_.norm());
    printf("|wb|= %8.4f ", wordBiases_.norm());
    printf("|z|= %8.4f ",  logZNorm);
    printf(" PPL= %7.4f", expf(-meanLogP));
    printf(" meanLogP= %7.4f", meanLogP);
    printf(" dataLLP= %7.4f", meanDataLLP);
    printf(" noiseLLP= %7.4f", meanNoiseLLP);
    printf("\n");
    fflush(stdout);
}

void
Net_LBL_2Reps_Scalable::initWordBiases(const WordStream &stream)
{
    for (int i = 0; i < nWords(); i++)
        wordBiases_[i] = 1;

    const int *words = stream.stream(0);
    for (size_t i = 0; i < stream.length(); i++)
    {
        assert(words[i] < nWords());
        wordBiases_[words[i]] += 1;
    }

    const int wordCount = stream.length()+nWords();
    for (int i = 0; i < nWords(); i++)
        wordBiases_[i] = logf(wordBiases_[i] / wordCount);
}

void
Net_LBL_2Reps_Scalable::initWordBiasesUniform()
{
    for (int i = 0; i < nWords(); i++)
        wordBiases_[i] = -logf(nWords());
}


static const char TRUE_FILE_HEADER[] = {"Net_LBL_2Reps"};
static const int  TRUE_FILE_VERSION  = 3;

int
Net_LBL_2Reps_Scalable::save(const char *filename) const
{
    FILE *fp = fopen(filename, "wb");

    if (!fp)
    {
        fprintf(stderr, "Error opening file %s.\n", filename);
        exit(-1);
    }

    // Write the header and version info.
    fwrite(TRUE_FILE_HEADER, sizeof(char), strlen(TRUE_FILE_HEADER), fp);
    fwrite(&TRUE_FILE_VERSION, sizeof(int), 1, fp);

    fwrite(&params_, sizeof(params_), 1, fp);

    fwrite(&contextSize_, sizeof(int), 1, fp);
    fwrite(&nWords_,      sizeof(int), 1, fp);
    fwrite(&nContextDims_, sizeof(int), 1, fp);
    fwrite(&nTargetDims_,  sizeof(int), 1, fp);

    fwrite(contextWeights_.data(), sizeof(float), contextWeights_.size(), fp);

    for (int i = 0; i < nWords(); i++)
        fwrite(contextReps_[i].data(), sizeof(float), contextReps_[i].size(), fp);

    fwrite(targetRepMat_.data(), sizeof(float), targetRepMat_.size(), fp);

    fwrite(wordBiases_.data(), sizeof(float), wordBiases_.size(), fp);

    fclose(fp);
    return 0;
}

int
Net_LBL_2Reps_Scalable::load(const char *filename)
{
    char     readFileHeader[1024];
    int      readFileVersion;
    
    FILE *fp = fopen(filename, "rb");

    if (!fp)
    {
        fprintf(stderr, "Error opening file %s.\n", filename);
        exit(-1);
    }

    // Read the header and version info.
    fread(readFileHeader, sizeof(char), strlen(TRUE_FILE_HEADER), fp);
    fread(&readFileVersion, sizeof(int), 1, fp);
//    printf("File version = %d\n", readFileVersion);

    if (strncmp(readFileHeader, TRUE_FILE_HEADER, strlen(TRUE_FILE_HEADER)))
    {
        fprintf(stderr, "Error: file %s has an unknown header.\n", filename);
        exit(-2);
    }

    if (readFileVersion != TRUE_FILE_VERSION)
    {
        fprintf(stderr, "Error: Version mismatch for file %s.\n", filename);
        exit(-3);
    }

    fread(&params_, sizeof(params_), 1, fp);

    fread(&contextSize_, sizeof(int), 1, fp);
    fread(&nWords_,      sizeof(int), 1, fp);
    fread(&nContextDims_, sizeof(int), 1, fp);
    fread(&nTargetDims_,  sizeof(int), 1, fp);
    printf("contextSize = %d  nWords = %d  nContextDims = %d  nTargetDims = %d\n",
           contextSize_, nWords_, nContextDims_, nTargetDims_); fflush(stdout);

    contextWeights_.resize(contextSize()*nContextDims(), nTargetDims());
    fread(contextWeights_.data(), sizeof(float), contextWeights_.size(), fp);

    contextReps_ = new Vector[nWords()];
    for (int i = 0; i < nWords(); i++)
    {
        contextReps_[i].resize(nContextDims());
        fread(contextReps_[i].data(), sizeof(float), contextReps_[i].size(), fp);
    }

    targetRepMat_.resize(nTargetDims(), nWords());
    fread(targetRepMat_.data(), sizeof(float), targetRepMat_.size(), fp);

    wordBiases_.resize(nWords());
    fread(wordBiases_.data(), sizeof(float), wordBiases_.size(), fp);

    printStats(-1, -1, 0);

    fclose(fp);

    return 0;
}

// Net_LBL_2Reps_Scalable_Params /////////////////////////////////////////////////////////////////////////////////////
Net_LBL_2Reps_Scalable_Params::Net_LBL_2Reps_Scalable_Params()
{
    ::memset(this, 0, sizeof(*this));
}

// Net_LBL_2Reps_Scalable_TrainParams /////////////////////////////////////////////////////////////////////////////////////
Net_LBL_2Reps_Scalable_TrainParams::Net_LBL_2Reps_Scalable_TrainParams()
{
    ::memset(this, 0, sizeof(*this));

    nEpochs = 10;

    printFreq = 1000;
    validFreq = 1000;
    saveFreq = int(1e20);

    pplStride = 1;

    nNoiseSamples = 1;

    lrDownscale = 1;
    initLrScale = 1;
}
