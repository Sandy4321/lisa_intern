// Copyright (c) 2006-2013 Andriy Mnih
#ifndef __MATRIX_H__
#define __MATRIX_H__

#include <assert.h>
#include <limits.h>
#include <math.h>
#include <values.h>
#include <stdio.h>
#include <cblas.h>

class Vector {
public: 
    int      myLength;
    float   *myData;
    bool     myOwnData;

             Vector();
             explicit Vector(const Vector &v);
             Vector(int length, const float *data = 0);
             Vector(int length, bool ownData, float *data);

            ~Vector();

    void     resize(int length, const float *data = 0);

    int      length() const { return myLength; }
    int      size() const   { return myLength; }

    const float *data() const { return myData; }
    float       *data()       { return myData; }

    void     copyFrom(const Vector *vec);
    void     add(const Vector *vec);
    void     addScaled(const Vector *vec, float scale);
    void     addScaled(const Vector *vec1, const Vector *vec2);
    void     addScaled(const Vector *vec1, const Vector *vec2, float scale);
    void     subtract(const Vector *vec);
    void     scale(float s);
    void     scaleTanhDerivs(const Vector *tanhVec);
    void     assign(float s);
    void     normalize();

    float    dot(const Vector *vec) const;

    float    min() const;
    float    max() const;
    float    norm() const;
    float    norm2() const;
    double   sum() const;
    int      maxIdx(int len = -1) const;

    float &operator [](int idx);
    const float &operator [](int idx) const;

    void     softMax(int len = -1);
    void     tanh();
    void     logistic();
    void     log();
    void     exp();
    void     negate();
    void     zero();

    float    rbmHidLogP() const;

    void     initFromGaussian(float stdev);
    void     initFromUniform(float halfWidth);
    void     decayL2(float decayRate);

    void     pruneDenormalized();

    friend   float dot (const Vector &v1, const Vector &v2);
    friend   float dot3(const Vector &v1, const Vector &v2, const Vector &v3);
};

class Matrix {
private:
    int      myRows, myCols;
    int      mySize;
    float   *myData;

public:
             Matrix();
             Matrix(int rows, int cols, const float *data = 0);
            ~Matrix();

    int      rows() const { return myRows; }
    int      cols() const { return myCols; }

    int      size() const { return mySize; }

    void     resize(int rows, int cols, const float *data = 0);

    const float *data() const { return myData; }
    float       *data()       { return myData; }
    const float *getData() const { return myData; }
    float       *getData()       { return myData; }

    const float *col(int c) const { return myData + c*myRows; }
    float       *col(int c)       { return myData + c*myRows; }

    float    norm() const;
    float    norm2() const;

    void     multiplyAdd(const Vector *vec, Vector *result) const;
    void     multiplyAdd(const Vector *vec, float *result) const;
    void     multiplyAdd(const Matrix *mat, int column, Vector *result) const;
    void     multiplyTransAdd(const Vector *vec, Vector *result) const;
    void     multiplyTransAdd(const float *vec, Vector *result) const;

    void     sparseMultiplyAdd(const short *colInds, const float *vals, int nInds, Vector *result) const;
    void     sparseBinaryMultiplyAdd(const short *colInds, int nInds, Vector *result) const;
    void     multiplyTransAddSparse(const Vector *vec, const short *colInds, int nInds, float *result) const;

    void     sparseMultiplyAddRatings(const short *colInds, const char *ratings, int nInds, Vector *result) const;

    void     addOuterProduct(const Matrix *mat, int column, const Vector *vec);
    void     addOuterProduct(const Vector *vec, const Matrix *mat, int column);
    void     addOuterProduct(const Vector *vec1, const Vector *vec2);
    void     addScaledOuterProduct(const Vector *vec1, const Vector *vec2, float scale);
    void     addScaledOuterProduct(const float *vec1, const Vector *vec2, float scale);
    void     addScaledBinaryOuterProductSparse(const short *colInds, int nInds,
                                               const Vector *colVec, float scale);
    void     addScaledOuterProductSparse(const float *rowVec, const short *colInds, int nInds,
                                         const Vector *colVec, float scale);

    void     copyColumn(Vector *target, int column) const;
    void     addToColumn(int column, const Vector *vec);
    void     addToColumnScaled(int column, const Vector *vec, float scale);
    void     addScaled(const Matrix *mat, float scale);
    void     add(const Matrix *mat);

    void     addScaledColumnSum(Vector *target, float scale);

    void     softMaxColumns();
    void     fillColumns(const Vector &vec);
    void     scaleColumn(int column, float scale);

    void     scaleAddAB(const Matrix &A, const Matrix &B, float targetScale, float prodScale = 1);
    void     scaleAddAtransB(const Matrix &A, const Matrix &B, float targetScale, float prodScale = 1);
    void     scaleAddABtrans(const Matrix &A, const Matrix &B, float targetScale, float prodScale = 1);

    void     zero();
    void     initFromGaussian(float stdev);
    void     initFromUniform(float halfWidth);
    void     decayL2(const short *colInds, int nInds, float decayRate);
    void     decayL2(float decayRate);

    void     pruneDenormalized();
};

class Random {
public:
    static  void fillGaussian(float *vec, int len, float stdev);
};


// Vector ///////////////////////////////////////////////////////////////////////////////////
inline
Vector::Vector()
{
    myLength = 0;
    myData   = 0;
    myOwnData = true;
}

inline
Vector::Vector(int length, const float *data)
{
    myLength = 0;
    myData   = 0;
    myOwnData = true;

    resize(length, data);
}

inline
Vector::Vector(int length, bool ownData, float *data)
{
    myLength = length;
    myData   = 0;
    myOwnData = ownData;

    if (ownData)
        resize(length, data);
    else
        myData = data;
}

inline
Vector::Vector(const Vector &v)
{
    if (&v == this) return;

    myLength = 0;
    myData   = 0;
    myOwnData = true;

    resize(v.length(), v.myData);
}

inline void
Vector::resize(int length, const float *data)
{
    assert(length > 0);

    if (myData && myOwnData) delete [] myData;

    myLength = length;

    myData = new float[myLength];

    if (data)
    {
        for (int i = 0; i < myLength; i++)
            myData[i] = data[i];
    }
    else
    {
        for (int i = 0; i < myLength; i++)
            myData[i] = 0.f;
    }
}


inline
Vector::~Vector()
{
    if (myData && myOwnData)
        delete [] myData;
}

inline float &
Vector::operator [](int idx)
{
    assert(idx < myLength);

    return myData[idx];
}

inline const float &
Vector::operator [](int idx) const
{
    assert(idx < myLength);

    return myData[idx];
}

inline float
Vector::min() const
{
    float val = myData[0];

    for (int i = 1; i < length(); i++)
    {
        if (myData[i] < val)
            val = myData[i];
    }

    return val;
}

inline float
Vector::max() const
{
    float val = myData[0];

    for (int i = 1; i < length(); i++)
    {
        if (myData[i] > val)
            val = myData[i];
    }

    return val;
}

inline int
Vector::maxIdx(int len) const
{
    if (len < 0)
        len = length();

    int idx = 0;
    float val = myData[0];
    for (int i = 1; i < len; i++)
    {
        if (val < myData[i])
        {
            val = myData[i];
            idx = i;
        }
    }

    return idx;
}


inline float
Vector::norm() const
{
    float nrm = 0;

    for (int i = 0; i < length(); i++)
        nrm += myData[i]*myData[i];

    return sqrtf(nrm);
}

inline float
Vector::norm2() const
{
    float nrm2 = 0;

    for (int i = 0; i < length(); i++)
        nrm2 += myData[i]*myData[i];

    return nrm2;
}

inline void
Vector::softMax(int len)
{
    const double maxVal = max();

    if (len < 0)
        len = length();

    float normSum = 0;
    for (int i = 0; i < len; i++)
    {
        const double expVal = ::exp(myData[i] - maxVal);
        normSum += expVal;
        myData[i] = expVal;
    }

    normSum = 1.f / normSum;
    for (int i = 0; i < len; i++)
        myData[i] *= normSum;
}

inline void
Vector::tanh()
{
    for (int i = 0; i < length(); i++)
        myData[i] = tanhf(myData[i]);
}

inline void
Vector::logistic()
{
    for (int i = 0; i < length(); i++)
        myData[i] = 1.f / (1.f + ::exp(-myData[i]));
}

inline void
Vector::log()
{
    for (int i = 0; i < length(); i++)
        myData[i] = logf(myData[i]);
}

inline void
Vector::exp()
{
    for (int i = 0; i < length(); i++)
        myData[i] = ::exp(myData[i]);
}

inline void
Vector::negate()
{
    for (int i = 0; i < length(); i++)
        myData[i] = -myData[i];
}

inline void
Vector::zero()
{
    for (int i = 0; i < length(); i++)
        myData[i] = 0;
}

inline void
Vector::copyFrom(const Vector *vec)
{
    assert(length() == vec->length());

    for (int i = 0; i < length(); i++)
        myData[i] = vec->myData[i];
}

inline void
Vector::add(const Vector *vec)
{
    assert(length() == vec->length());

    for (int i = 0; i < length(); i++)
        myData[i] += vec->myData[i];
}

inline void
Vector::addScaled(const Vector *vec, float scale)
{
    assert(length() == vec->length());

    for (int i = 0; i < length(); i++)
        myData[i] += scale*vec->myData[i];
}

inline void
Vector::addScaled(const Vector *vec1, const Vector *vec2)
{
    assert(length() == vec1->length());
    assert(length() == vec2->length());

    for (int i = 0; i < length(); i++)
        myData[i] += vec1->myData[i]*vec2->myData[i];
}

inline void
Vector::addScaled(const Vector *vec1, const Vector *vec2, float scale)
{
    assert(length() == vec1->length());
    assert(length() == vec2->length());

    for (int i = 0; i < length(); i++)
        myData[i] += vec1->myData[i]*vec2->myData[i]*scale;
}

inline void
Vector::subtract(const Vector *vec)
{
    assert(length() == vec->length());

    for (int i = 0; i < length(); i++)
        myData[i] -= vec->myData[i];
}

inline void
Vector::scale(float s)
{
    for (int i = 0; i < length(); i++)
        myData[i] *= s;
}

inline double 
Vector::sum() const
{
    double s = 0;
    for (int i = 0; i < length(); i++)
        s += myData[i];

    return s;
}

inline void
Vector::assign(float v)
{
    for (int i = 0; i < length(); i++)
        myData[i] = v;
}

inline void
Vector::scaleTanhDerivs(const Vector *tanhVec)
{
    const float *tanhVals = tanhVec->myData;

    for (int i = 0; i < length(); i++)
        myData[i] *= 1.f - tanhVals[i]*tanhVals[i];
}

inline float
Vector::dot(const Vector *vec) const
{
    float v = 0;

    assert(length() == vec->length());

    for (int i = 0; i < length(); i++)
        v += myData[i]*vec->myData[i];

    return v;
}

inline void
Vector::normalize()
{
    const float n = norm();
    if (n > FLT_MIN)
        scale(1./n);
}

inline void
Vector::decayL2(float decayRate)
{
    const float scale = 1.f - decayRate;

    for (int i = 0; i < length(); i++)
        myData[i] *= scale;
}

inline void
Vector::pruneDenormalized()
{
    for (int i = 0; i < length(); i++)
    {
        if (fpclassify(myData[i]) == FP_SUBNORMAL)
            myData[i] = 0;
    }
}


inline float
dot(const Vector &v1, const Vector &v2)
{
    float d = 0;

    assert(v1.length() == v2.length());

    for (int i = 0; i < v1.length(); i++)
        d += v1.myData[i]*v2.myData[i];

    return d;
}

inline float
dot3(const Vector &v1, const Vector &v2, const Vector &v3)
{
    float d = 0;

    assert(v1.length() == v2.length() && v2.length() == v3.length());

    for (int i = 0; i < v1.length(); i++)
        d += v1.myData[i]*v2.myData[i]*v3.myData[i];

    return d;
}

inline float
dist2(const Vector *vec1, const Vector *vec2)
{
    float v = 0;

    assert(vec1->length() == vec2->length());

    for (int i = 0; i < vec1->length(); i++)
    {
        const float d = vec1->myData[i] - vec2->myData[i];
        v += d*d;
    }

    return v;
}

// Matrix ///////////////////////////////////////////////////////////////////////////////////
//
inline
Matrix::Matrix()
{
    myRows = 0;
    myCols = 0;
    myData = 0;
}

inline
Matrix::Matrix(int rows, int cols, const float *data)
{
    myData = 0;

    resize(rows, cols, data);
}

inline void
Matrix::resize(int rows, int cols, const float *data)
{
    myRows = rows;
    myCols = cols;
    assert(myRows > 0 && myCols > 0);

    assert("The matrix has more than INT_MAX elements!" && INT_MAX / rows >= cols);

    mySize = myRows*myCols;

    if (myData) delete [] myData;

    myData = new float[mySize];

    if (data)
    {
        for (int i = 0; i < mySize; i++)
            myData[i] = data[i];
    }
    else
    {
        for (int i = 0; i < mySize; i++)
            myData[i] = 0.f;
    }
}

inline
Matrix::~Matrix()
{
    delete [] myData;
}


inline void
Matrix::copyColumn(Vector *target, int column) const
{
    assert(rows() == target->length());
    assert(column < cols());

    const float *vec  = myData + column*rows();
    for (int r = 0; r < rows(); r++)
        target->myData[r] = vec[r];
}

inline void
Matrix::addToColumn(int column, const Vector *vec)
{
    assert(rows() == vec->length());
    assert(column < cols());

    float *data = myData + column*rows();
    for (int r = 0; r < rows(); r++)
        data[r] += vec->myData[r];
}

inline void
Matrix::addToColumnScaled(int column, const Vector *vec, float scale)
{
    assert(rows() == vec->length());
    assert(column < cols());

    float *data = myData + column*rows();
    for (int r = 0; r < rows(); r++)
        data[r] += scale*vec->myData[r];
}

inline void
Matrix::scaleColumn(int column, float scale)
{
    assert(column < cols());

    float *data = myData + column*rows();
    for (int r = 0; r < rows(); r++)
        data[r] *= scale;
}

inline void
Matrix::addScaled(const Matrix *mat, float scale)
{
    assert(rows() == mat->rows());
    assert(cols() == mat->cols());

    for (int i = 0; i < rows()*cols(); i++)
        myData[i] += scale*mat->myData[i];
}

inline void
Matrix::add(const Matrix *mat)
{
    assert(rows() == mat->rows());
    assert(cols() == mat->cols());

    for (int i = 0; i < rows()*cols(); i++)
        myData[i] += mat->myData[i];
}

inline void
Matrix::addScaledColumnSum(Vector *target, float scale)
{
    assert(rows() == target->length());

    int idx = 0;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            target->myData[r] += scale*myData[idx++];
    }
}

inline float
Matrix::norm() const
{
    float nrm = 0;

    for (int i = 0; i < cols()*rows(); i++)
        nrm += myData[i]*myData[i];

    return sqrtf(nrm);
}

inline float
Matrix::norm2() const
{
    float nrm2 = 0;

    for (int i = 0; i < cols()*rows(); i++)
        nrm2 += myData[i]*myData[i];

    return nrm2;
}

inline void
Matrix::pruneDenormalized()
{
    for (int i = 0; i < cols()*rows(); i++)
    {
        if (fpclassify(myData[i]) == FP_SUBNORMAL)
            myData[i] = 0;
    }
}


inline void
Matrix::softMaxColumns()
{
    float *data = myData;
    for (int c = 0; c < cols(); c++)
    {
        float maxVal = data[0];
        for (int r = 1; r < rows(); r++)
            if (maxVal < data[r])
                maxVal = data[r];

        float normSum = 0;
        for (int r = 0; r < rows(); r++)
        {
            const double expVal = ::exp(data[r] - maxVal);
            normSum += expVal;
            data[r] = expVal;
        }

        normSum = 1.f / normSum;
        for (int r = 0; r < rows(); r++)
            data[r] *= normSum;

        data += rows();
    }
}

inline void
Matrix::fillColumns(const Vector &vec)
{
    assert(vec.length() == rows());

    float *target = data();
    for (int c = 0; c < cols(); c++)
    {
        const float *source = vec.data();
        for (int r = 0; r < rows(); r++)
            *target++ = *source++;
    }
}

#endif
