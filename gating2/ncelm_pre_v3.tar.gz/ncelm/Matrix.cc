// Copyright (c) 2006-2013 Andriy Mnih
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "util.h"
#include "Matrix.h"

// Vector ///////////////////////////////////////////////////////////////////////////////////

void
Vector::initFromGaussian(float stdev)
{
    Random::fillGaussian(myData, length(), stdev);
}

void
Vector::initFromUniform(float halfWidth)
{
    for (int i = 0; i < length(); i++)
        myData[i] = (2.f*Rand()-1.f)*halfWidth;
}

// Matrix ///////////////////////////////////////////////////////////////////////////////////

void
Matrix::multiplyAdd(const Vector *vec, Vector *result) const
{
    assert(cols() == vec->length());
    assert(rows() == result->length());

    const float *data = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            result->myData[r] += vec->myData[c]*data[r];

        data += rows();
    }
}

void
Matrix::multiplyAdd(const Vector *vec, float *result) const
{
    assert(cols() == vec->length());

    const float *data = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            result[r] += vec->myData[c]*data[r];

        data += rows();
    }
}

void
Matrix::multiplyTransAdd(const Vector *vec, Vector *result) const
{
    assert(rows() == vec->length());
    assert(cols() == result->length());

    const float *data = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            result->myData[c] += vec->myData[r]*data[r];

        data += rows();
    }
}

void
Matrix::multiplyTransAdd(const float *vec, Vector *result) const
{
    assert(cols() == result->length());

    const float *data = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            result->myData[c] += vec[r]*data[r];

        data += rows();
    }
}

void
Matrix::multiplyAdd(const Matrix *mat, int column, Vector *result) const
{
    assert(cols() == mat->rows());
    assert(rows() == result->length());
    assert(column < mat->cols());

    const float *data = myData;
    const float *vec  = mat->myData + column*mat->rows();
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            result->myData[r] += vec[c]*data[r];

        data += rows();
    }
}

void
Matrix::sparseMultiplyAdd(const short *colInds, const float *vals, int nInds, Vector *result) const
{
    assert(rows() == result->length());

    for (int i = 0; i < nInds; i++)
    {
        assert(colInds[i] < cols());

        const float *data = myData + colInds[i]*rows();
        for (int r = 0; r < rows(); r++)
            result->myData[r] += vals[i]*data[r];
    }
}

void
Matrix::sparseBinaryMultiplyAdd(const short *colInds, int nInds, Vector *result) const
{
    assert(rows() == result->length());

    for (int i = 0; i < nInds; i++)
    {
        assert(colInds[i] < cols());

        const float *data = myData + colInds[i]*rows();
        for (int r = 0; r < rows(); r++)
            result->myData[r] += data[r];
    }
}

void
Matrix::sparseMultiplyAddRatings(const short *colInds, const char *ratings, int nInds, Vector *result) const
{
    assert(rows() == result->length());

    for (int i = 0; i < nInds; i++)
    {
        assert(colInds[i] < cols());

        const float *data = myData + (colInds[i]*5 + ratings[i] - 1)*rows();
        for (int r = 0; r < rows(); r++)
            result->myData[r] += data[r];
    }
}

void
Matrix::multiplyTransAddSparse(const Vector *vec, const short *colInds, int nInds, float *result) const
{
    assert(rows() == vec->length());

    for (int i = 0; i < nInds; i++)
    {
        assert(colInds[i] < cols());

        const float *data = myData + colInds[i]*rows();
        for (int r = 0; r < rows(); r++)
            result[i] += vec->myData[r]*data[r];
    }
}

void
Matrix::initFromGaussian(float stdev)
{
    Random::fillGaussian(myData, rows()*cols(), stdev);
}

void
Matrix::initFromUniform(float halfWidth)
{
    for (int i = 0; i < rows()*cols(); i++)
        myData[i] = (2.f*Rand()-1.f)*halfWidth;
}

void
Matrix::zero()
{
    for (int i = 0; i < rows()*cols(); i++)
        myData[i] = 0;
}

void
Matrix::addOuterProduct(const Vector *vec, const Matrix *mat, int column)
{
    assert(rows() == vec->length());
    assert(cols() == mat->rows());
    assert(column < mat->cols());

    const float *v1 = vec->myData;
    const float *v2 = mat->myData + column*mat->rows();

    float *target = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            *target++ += v1[r]*v2[c];
    }
}

void
Matrix::addOuterProduct(const Vector *vec1, const Vector *vec2)
{
    assert(rows() == vec1->length());
    assert(cols() == vec2->length());

    const float *v1 = vec1->myData;
    const float *v2 = vec2->myData;

    float *target = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            *target++ += v1[r]*v2[c];
    }
}

void
Matrix::addScaledOuterProduct(const float *vec1, const Vector *vec2, float scale)
{
    assert(cols() == vec2->length());

    const float *v2 = vec2->myData;

    float *target = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            *target++ += scale*vec1[r]*v2[c];
    }
}

void
Matrix::addScaledOuterProduct(const Vector *vec1, const Vector *vec2, float scale)
{
    assert(rows() == vec1->length());
    assert(cols() == vec2->length());

    const float *v1 = vec1->myData;
    const float *v2 = vec2->myData;

    float *target = myData;
    for (int c = 0; c < cols(); c++)
    {
        for (int r = 0; r < rows(); r++)
            *target++ += scale*v1[r]*v2[c];
    }
}

void
Matrix::addScaledOuterProductSparse(const float *rowVec, const short *colInds, int nInds,
                                    const Vector *colVec, float scale)
{
    assert(rows() == colVec->length());

    for (int i = 0; i < nInds; i++)
    {
        assert(colInds[i] < cols());

        float *data = myData + colInds[i]*rows();
        for (int r = 0; r < rows(); r++)
            data[r] += scale*rowVec[i]*colVec->myData[r];
    }
}

void
Matrix::addScaledBinaryOuterProductSparse(const short *colInds, int nInds,
                                          const Vector *colVec, float scale)
{
    assert(rows() == colVec->length());

    for (int i = 0; i < nInds; i++)
    {
        assert(colInds[i] < cols());

        float *data = myData + colInds[i]*rows();
        for (int r = 0; r < rows(); r++)
            data[r] += scale*colVec->myData[r];
    }
}

void
Matrix::decayL2(const short *colInds, int nInds, float decayRate)
{
    for (int i = 0; i < nInds; i++)
    {
        assert(colInds[i] < cols());

        float *data = myData + colInds[i]*rows();
        for (int r = 0; r < rows(); r++)
            data[r] -= decayRate*data[r];
    }
}

void
Matrix::decayL2(float decayRate)
{
    for (int i = 0; i < rows()*cols(); i++)
        myData[i] -= decayRate*myData[i];
}

void
Matrix::scaleAddAB(const Matrix &A, const Matrix &B, float targetScale, float prodScale)
{
    assert(A.rows() == rows() && A.cols() == B.rows() && B.cols() == cols());

    ::cblas_sgemm(CblasColMajor, CblasNoTrans, CblasNoTrans,
        A.rows(), B.cols(), A.cols(),
        prodScale, // Scale the product by this
        A.data(), A.rows(),
        B.data(), B.rows(),
        targetScale, // Scale the target by this before adding the product matrix
        data(), rows());
}

void
Matrix::scaleAddAtransB(const Matrix &A, const Matrix &B, float targetScale, float prodScale)
{
    assert(A.cols() == rows() && A.rows() == B.rows() && B.cols() == cols());

    ::cblas_sgemm(CblasColMajor, CblasTrans, CblasNoTrans,
        A.cols(), B.cols(), A.rows(),
        prodScale, // Scale the product by 1
        A.data(), A.rows(),
        B.data(), B.rows(),
        targetScale, // Scale the target by this before adding the product matrix
        data(), rows());
}

void
Matrix::scaleAddABtrans(const Matrix &A, const Matrix &B, float targetScale, float prodScale)
{
    assert(A.rows() == rows() && A.cols() == B.cols() && B.rows() == cols());

    ::cblas_sgemm(CblasColMajor, CblasNoTrans, CblasTrans,
        A.rows(), B.rows(), A.cols(),
        prodScale, // Scale the product by 1
        A.data(), A.rows(),
        B.data(), B.rows(),
        targetScale, // Scale the target by this before adding the product matrix
        data(), rows());
}

// Random ///////////////////////////////////////////////////////////////////////////////////
void
Random::fillGaussian(float *vec, int len, float stdev)
{
    static const float TwoPi = 2*M_PI;

    for (int i = 0; i < len; i++)
    {
        float rnd = Rand();

        if (rnd < 1e-6) rnd = 1e-6;
        vec[i] = stdev * sqrtf(-2.f * logf(rnd)) * cosf(TwoPi * Rand());
        assert(isfinite(vec[i]));
    }
}
