g++ -Wall -O3 -g -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=0 Matrix.cc -lcblas util.cc word_io.cc net_lbl_2reps_scalable.cc train_lbl_2r_ptb.cc -o train_lbl_2r_ptb
